﻿import 'dart:async';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'ChatService.dart';

class ChatScreenNew extends StatefulWidget {
  const ChatScreenNew({super.key});

  @override
  State<ChatScreenNew> createState() => _ChatScreenNewState();
}

class _ChatScreenNewState extends State<ChatScreenNew> {
  final ChatService _chatService = ChatService();
  final GetStorage _storage = GetStorage();
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  List<ChatMessage> _messages = [];
  bool _isLoading = false;
  bool _isSending = false;
  int _lastMessageId = 0;
  Timer? _pollingTimer;

  @override
  void initState() {
    super.initState();
    print('[ChatScreen] Initializing Chat Screen...');
    _loadChatHistory();
    _startPolling();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _pollingTimer?.cancel();
    super.dispose();
  }

  /// Load chat history from server
  Future<void> _loadChatHistory() async {
    setState(() => _isLoading = true);

    try {
      final messages = await _chatService.getChatHistory();
      setState(() {
        _messages = messages;
        if (_messages.isNotEmpty) {
          _lastMessageId = _messages.last.id;
        }
      });

      // Scroll to bottom after loading
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToBottom();
      });
      print('[ChatScreen] Loaded ${messages.length} messages from history');
    } catch (e) {
      print('[ChatScreen] Error loading chat history: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  /// Start polling for new messages every 3 seconds
  void _startPolling() {
    print('[ChatScreen] Starting Poll for new messages...');
    _pollingTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      _checkForNewMessages();
    });
  }

  /// Check for new messages from admin
  Future<void> _checkForNewMessages() async {
    try {
      final newMessages = await _chatService.getNewMessages(
        lastMessageId: _lastMessageId,
      );

      if (newMessages.isNotEmpty && mounted) {
        print('[ChatScreen] Received ${newMessages.length} new messages');
        setState(() {
          _messages.addAll(newMessages);
          if (_messages.isNotEmpty) {
            _lastMessageId = _messages.last.id;
          }
        });

        // Auto-scroll to bottom when new messages arrive
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _scrollToBottom();
        });
      }
    } catch (e) {
      log('[ChatScreen] Error checking new messages: $e');
    }
  }

  /// Send message to admin
  Future<void> _sendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty || _isSending) return;

    setState(() => _isSending = true);

    try {
      // Optimistically add message to UI
      final tempMessage = ChatMessage(
        id: -1, // Temporary ID
        senderId: _chatService.currentUserId ?? 0,
        receiverId: ChatService.adminId,
        message: message,
        type: 'text',
        createdAt: DateTime.now(),
      );

      setState(() {
        _messages.add(tempMessage);
      });

      _scrollToBottom();
      _messageController.clear();

      // Send to server
      final response = await _chatService.sendMessage(message: message);

      if (response['status'] == true) {
        log('[ChatScreen] Message sent successfully');
        // Update with real ID if available
        if (response['info'] != null && response['info']['id'] != null) {
          final realId = int.tryParse(response['info']['id'].toString()) ?? 0;
          final index = _messages.indexWhere((m) => m.id == -1);
          if (index != -1 && mounted) {
            setState(() {
              _messages[index] = ChatMessage(
                id: realId,
                senderId: _messages[index].senderId,
                receiverId: _messages[index].receiverId,
                message: _messages[index].message,
                type: _messages[index].type,
                createdAt: _messages[index].createdAt,
              );
            });
          }
        }
      } else {
        // Remove failed message
        if (mounted) {
          setState(() {
            _messages.removeWhere((m) => m.id == -1);
          });
        }
        _showSnackBar(response['msg'] ?? 'Failed to send message', isError: true);
      }
    } catch (e) {
      log('[ChatScreen] Error sending message: $e');
      // Remove failed message
      if (mounted) {
        setState(() {
          _messages.removeWhere((m) => m.id == -1);
        });
      }
      _showSnackBar('Error sending message', isError: true);
    } finally {
      if (mounted) {
        setState(() => _isSending = false);
      }
    }
  }

  /// Scroll to bottom of chat
  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  /// Show snackbar
  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
      ),
    );
  }

  /// Format time
  String _formatTime(DateTime time) {
    final hour = time.hour.toString().padLeft(2, '0');
    final minute = time.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Chat Support',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        backgroundColor: const Color(0xFFFDB564),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            onPressed: _loadChatHistory,
          ),
        ],
      ),
      body: Column(
        children: [
          // Messages List
          Expanded(
            child: _isLoading && _messages.isEmpty
                ? const Center(
                    child: CircularProgressIndicator(color: Color(0xFFFDB564)),
                  )
                : _messages.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.chat_bubble_outline,
                              size: 80,
                              color: Colors.grey.shade400,
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'No messages yet',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.grey.shade600,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Start a conversation with admin',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey.shade500,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 16,
                        ),
                        itemCount: _messages.length,
                        itemBuilder: (context, index) {
                          final message = _messages[index];
                          final isCurrentUser =
                              message.senderId == _chatService.currentUserId;

                          return _buildMessageBubble(
                            message: message.message,
                            time: message.createdAt,
                            isCurrentUser: isCurrentUser,
                          );
                        },
                      ),
          ),

          // Message Input
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 4,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: SafeArea(
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF5F5F5),
                        borderRadius: BorderRadius.circular(25),
                        border: Border.all(
                          color: const Color(0xFFFDB564).withOpacity(0.3),
                        ),
                      ),
                      child: TextField(
                        controller: _messageController,
                        maxLines: null,
                        textCapitalization: TextCapitalization.sentences,
                        decoration: const InputDecoration(
                          hintText: 'Type a message...',
                          border: InputBorder.none,
                          hintStyle: TextStyle(color: Colors.grey),
                        ),
                        style: const TextStyle(fontSize: 16),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    decoration: const BoxDecoration(
                      color: Color(0xFFFDB564),
                      shape: BoxShape.circle,
                    ),
                    child: IconButton(
                      icon: _isSending
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                                strokeWidth: 2,
                              ),
                            )
                          : const Icon(Icons.send, color: Colors.white),
                      onPressed: _isSending ? null : _sendMessage,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Build message bubble widget
  Widget _buildMessageBubble({
    required String message,
    required DateTime time,
    required bool isCurrentUser,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: isCurrentUser
            ? MainAxisAlignment.end
            : MainAxisAlignment.start,
        children: [
          Container(
            constraints: BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width * 0.75,
            ),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: isCurrentUser
                  ? const Color(0xFFFDB564)
                  : Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(16),
                topRight: const Radius.circular(16),
                bottomLeft: Radius.circular(isCurrentUser ? 16 : 4),
                bottomRight: Radius.circular(isCurrentUser ? 4 : 16),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  message,
                  style: TextStyle(
                    color: isCurrentUser ? Colors.white : Colors.black87,
                    fontSize: 15,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      _formatTime(time),
                      style: TextStyle(
                        color: isCurrentUser
                            ? Colors.white.withOpacity(0.8)
                            : Colors.grey.shade600,
                        fontSize: 11,
                      ),
                    ),
                    if (isCurrentUser) ...[
                      const SizedBox(width: 4),
                      Icon(
                        Icons.done_all,
                        size: 14,
                        color: Colors.white.withOpacity(0.8),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
