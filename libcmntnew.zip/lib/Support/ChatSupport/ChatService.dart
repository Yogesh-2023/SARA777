import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart' as http;
import 'package:get_storage/get_storage.dart';
import '../../ulits/Constents.dart';

class ChatMessage {
  final int id;
  final int senderId;
  final int receiverId;
  final String message;
  final String type;
  final DateTime createdAt;

  ChatMessage({
    required this.id,
    required this.senderId,
    required this.receiverId,
    required this.message,
    required this.type,
    required this.createdAt,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    return ChatMessage(
      id: int.tryParse(json['id']?.toString() ?? '0') ?? 0,
      senderId: int.tryParse(json['sender_id']?.toString() ?? '0') ?? 0,
      receiverId: int.tryParse(json['receiver_id']?.toString() ?? '0') ?? 0,
      message: json['message']?.toString() ?? '',
      type: json['type']?.toString() ?? 'text',
      createdAt: DateTime.parse(
        json['created_at']?.toString() ?? DateTime.now().toIso8601String(),
      ),
    );
  }
}

class ChatService {
  final GetStorage _storage = GetStorage();
  
  // Admin ID is typically 1
  static const int adminId = 1;

  /// Get current user's ID
  int? get currentUserId {
    // Try 'userId' first as requested
    var idV = _storage.read('userId');
    if (idV == null || idV.toString().isEmpty) {
      // Fallback to 'registerId'
      idV = _storage.read('registerId');
    }
    
    print('[ChatService] Raw ID from storage (userId/regId): $idV (${idV?.runtimeType})');
    return int.tryParse(idV?.toString() ?? '');
  }

  /// Get auth token
  String? get authToken {
    final token = _storage.read('accessToken');
    print('[ChatService] Raw accessToken from storage: ${token != null ? "EXISTS" : "NULL"}');
    return token;
  }

  /// Headers for API requests
  Map<String, String> get headers {
    final token = authToken;
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
  }

  /// Send a message to admin
  Future<Map<String, dynamic>> sendMessage({
    required String message,
    String type = 'text',
  }) async {
    try {
      final userId = currentUserId;
      if (userId == null) {
        print('[ChatService] ERROR: Cannot send message because userId is null');
        return {'status': false, 'msg': 'User not logged in'};
      }

      final url = '${Constant.apiEndpoint}chat/send';
      final body = {
        'sender_id': userId.toString(),
        'receiver_id': adminId.toString(),
        'message': message,
        'type': type,
      };

      print('[ChatService] SEND MESSAGE REQUEST:');
      print('  URL: $url');
      print('  HEADERS: $headers');
      print('  BODY: ${json.encode(body)}');

      final response = await http.post(
        Uri.parse(url),
        headers: headers,
        body: json.encode(body),
      );

      print('[ChatService] SEND MESSAGE RESPONSE: ${response.statusCode}');
      print('  BODY: ${response.body}');

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        return {'status': false, 'msg': 'Failed to send message'};
      }
    } catch (e) {
      log('[ChatService] Send Message Error: $e');
      return {'status': false, 'msg': 'Error: $e'};
    }
  }

  /// Get chat history between user and admin
  Future<List<ChatMessage>> getChatHistory() async {
    try {
      final userId = currentUserId;
      if (userId == null) {
        return [];
      }

      final uri = Uri.parse('${Constant.apiEndpoint}chat/history').replace(
        queryParameters: {
          'user_id': userId.toString(),
          'receiver_id': adminId.toString(),
        },
      );

      print('[ChatService] GET CHAT HISTORY REQUEST:');
      print('  URL: $uri');
      print('  HEADERS: $headers');

      final response = await http.get(uri, headers: headers);

      print('[ChatService] GET CHAT HISTORY RESPONSE: ${response.statusCode}');
      print('  BODY: ${response.body}');

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == true) {
          final List messages = (data['messages'] ?? data['info'] ?? []) as List;
          return messages
              .map((msg) => ChatMessage.fromJson(msg as Map<String, dynamic>))
              .toList();
        }
      }
      return [];
    } catch (e) {
      log('[ChatService] Get Chat History Error: $e');
      return [];
    }
  }

  /// Get new messages (polling)
  Future<List<ChatMessage>> getNewMessages({required int lastMessageId}) async {
    try {
      final userId = currentUserId;
      if (userId == null) {
        return [];
      }

      final uri = Uri.parse('${Constant.apiEndpoint}chat/messages').replace(
        queryParameters: {
          'receiver_id': userId.toString(),
          'last_message_id': lastMessageId.toString(),
        },
      );

      print('[ChatService] GET NEW MESSAGES REQUEST:');
      print('  URL: $uri');
      print('  HEADERS: $headers');

      final response = await http.get(uri, headers: headers);

      print('[ChatService] GET NEW MESSAGES RESPONSE: ${response.statusCode}');
      print('  BODY: ${response.body}');

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == true) {
          final List messages = (data['messages'] ?? data['info'] ?? []) as List;
          return messages
              .map((msg) => ChatMessage.fromJson(msg as Map<String, dynamic>))
              .toList();
        }
      }
      return [];
    } catch (e) {
      log('[ChatService] Get New Messages Error: $e');
      return [];
    }
  }
}
