import 'package:flutter/material.dart';

class HistoryPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFCD91),
      body: Center(child: Text("History Page", style: TextStyle(color: Color(0xFF0000FF)))),
    );
  }
}
